from dicegame.runner import GameRunner


def main():
    print("Add the values of the dice")
    print("It's really that easy")
    print("What are you doing with your life.")
    GameRunner.run()


if __name__ == "__main__":
    main()
